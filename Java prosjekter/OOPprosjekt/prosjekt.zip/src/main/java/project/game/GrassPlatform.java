package project.game;

public class GrassPlatform extends GameObject{
    private boolean crackedPlatform;
    public GrassPlatform(double x, double y, boolean crackedPlatform){
        super(x,y,200,150);
        this.crackedPlatform = crackedPlatform;
    }
    public boolean getCrackedPlatform(){
        return this.crackedPlatform;
    }
    public void setXPos(double x){
        this.x = x;
    }
}
