package project.game;

public interface GameStateObserver {
    void handle();
}
