package project.game;

public class GameObject{
    protected double x;
    protected double y;
    private double width;
    private double height;

    public GameObject(double x, double y, double width, double height) {
        if(width<0){
            this.width = 100;
        }
        if(height<0){
            this.height = 100;
        }
        if(x<0){
            // Hvis x er under 0, setter vi den til standard 0:
            this.x = 0;
        }
        if(y<0){
            this.y = 0;
        }

        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
    }
    public double getXPos(){
        return this.x;
    }
    public double getYPos(){
        return this.y;
    }
    public double getWidth(){
        return this.width;
    }
    public double getHeight(){
        return this.height;
    }
    public void setYPos(double y) {
        this.y = y;
    }

}
