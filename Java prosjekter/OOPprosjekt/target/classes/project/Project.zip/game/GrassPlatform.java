package project.game;

public class GrassPlatform extends GameObject{
    public GrassPlatform(double x, double y){
        super(x,y,200,150);
    }
}
